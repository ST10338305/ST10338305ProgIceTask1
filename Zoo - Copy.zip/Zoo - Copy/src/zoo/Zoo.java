/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package zoo;

import java.util.Scanner;

/**
 *
 * @author David
 */
public class Zoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
          Scanner kb = new Scanner(System.in);
          
          
          
          
            bird brd = new bird();
        reptile rep = new reptile();

        System.out.println("Welcome to the program");
        System.out.println("Please enter one of the follwoing species: bird or reptile ");
        boolean userinput=false;
    
        
        while (!userinput) {
        String userInput = kb.next();  
        
        if (userInput.equalsIgnoreCase("bird")){   
            
                
                    System.out.println("\nEntering the information for the bird");
                    brd.input();
                    System.out.println("***********************************");
                    System.out.println("The report of the animal is:");
                    System.out.println("***********************************\n");
                    brd.output();
                    userinput = true;
                }
        
                if (userInput.equalsIgnoreCase("reptile")) {
                    System.out.println("\nEnter the information for the reptile");
                    rep.input();
                    System.out.println("***********************************");
                    System.out.println("The report of the animal is:");
                    System.out.println("***********************************\n");
                    rep.output();
                    userinput=true;
                }
                    
                            
        }
    }
}
          
        
                
        
      
        
    

    

    
    
    
    

