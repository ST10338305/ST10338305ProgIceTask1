/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoo;

import java.util.Scanner;

/**
 *
 * @author David
 */
public class reptile extends animal {
    
    private Double bloodtype;

    public Double getBloodtype() {
        return bloodtype;
    }

    public void setBloodtype(Double bloodtype) {
        this.bloodtype = bloodtype;
    }
    
     @Override   
    public void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter blood temperature: ");
        bloodtype = scanner.nextDouble();
    }
    
    @Override   
    public void output() {
        super.output();
        System.out.println("Blood temperature: " + bloodtype);
    }
}
    

