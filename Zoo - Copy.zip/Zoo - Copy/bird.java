/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoo;

import java.util.Scanner;

/**
 *
 * @author David
 */
public class bird extends animal {
    
    private int colour;

    public int getColour() {
        return colour;
    }

    public void setColour(int colour) {
        this.colour = colour;
    }  
          
    @Override
         public void input() {
        super.input();  
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter feather colour: "
                + "(1) for grey"
                + "(2) for white"
                + "(3) for black");
        colour = scanner.nextInt();
    }

    @Override  
    public void output() {
        super.output();
        if (colour==1) {
            System.out.println("Colour is grey");
        }
          if(colour==2){
                        System.out.println("Colour is white");
          }
                        if(colour==3){
                        
                            System.out.println("coulor is black");
                        }
                    }
        }
    
 

    
    

