/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoo;

import java.util.Scanner;

/**
 *
 * @author David
 */
public class animal {
    
    private int id;
    private String species;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
    /**
     *
     */
         public void input()
        {
        Scanner kb = new Scanner(System.in);
        animal animal = new animal();
        
        System.out.print("Enter ID tag: ");
        id = kb.nextInt();  
        animal.setId(id);
        kb.nextLine();
        System.out.print("Enter species: ");
        species = kb.nextLine();  
        animal.setSpecies(species);
    }

    
        public void output() {
        System.out.println("The identification of the animal: " + id);
        System.out.println("The species of the animal: " + species);
    }
    

}
